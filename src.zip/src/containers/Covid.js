import React from "react";

const Covid = (props) => {
	console.log("props", props)
	return(
		<div>Covid-19</div>
	)
};

export default Covid;